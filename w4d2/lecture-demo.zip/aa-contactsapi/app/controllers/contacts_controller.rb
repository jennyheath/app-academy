class ContactsController < ApplicationController
  def create
    @contact = Contact.new(contact_params)

    if @contact.save
      render :json => @contact, :status => :created
    else
      flash.now[:errors] = @contact.errors.full_messages
      render :new
    end
  end

  def destroy
    @contact = Contact.find(params[:id])
    @contact.destroy
    render json: @contact
  end

  def edit
    @contact = Contact.find(params[:id])
    render :edit
  end

  def new
    @contact = Contact.new
    render :new
  end

  def index
    @user = User.find(params[:user_id])
    @contacts = Contact.contacts_for_user_id(params[:user_id])
    render :index
  end

  def show
    render :json => Contact.find(params[:id])
  end

  def update
    @contact = Contact.find(params[:id])

    if @contact.update(contact_params)
      render :json => @contact
    else
      flash.now[:errors] = @contact.errors.full_messages
      render :edit
    end
  end

  private
  def contact_params
    params.require(:contact).permit(:name, :email, :user_id)
    params[:contact].permit(:name, :email, :user_id)
  end
end
